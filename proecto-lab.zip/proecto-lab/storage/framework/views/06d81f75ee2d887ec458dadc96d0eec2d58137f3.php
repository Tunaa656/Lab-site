<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\proecto-lab\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>